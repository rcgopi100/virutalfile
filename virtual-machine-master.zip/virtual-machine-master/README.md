# Software Professions Project

Enhance or replace current virtual machine for assembling assembly programs.

Team Members:
Sang Mai,
Zyra De Los Reyes,
Abdullah Altamimi,
Omer Muhit